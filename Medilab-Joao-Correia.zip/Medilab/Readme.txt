

Descarrega o projeto em anexo.
Cria um projeto no teu Xampp e associa a pasta medilab

Personaliza o template para:
Cores - retira os azuis e vamos colocar os laranjas (qualquer laranja a escolha)
Menu ficará:  Home, Sobre, serviços, departamentos, medicos, clinicas (lisboa, porto, coimbra, evora, faro) e contactos. Botao Marcação
Traduzir titulos de ingles para PT.

Os contadores vao passar a: 105 medicos, 25 departamentos, 10 laboratorios, 155 premios

Nos serviços acrescentar 3 serviços

Formulario de marcação traduzir os placeholders dos inputs apresentados

Departamentos todos para PT

Medicos: 
Acrescentar 2 medicos (Joana Maria de clinica geral e Joao Mario de cardiologia) estes dois não tem twitter

Acrescentar 2 faqs

Acrescentar 2 comentários o do Joaquim e da Joaquina que sao ambos doentes

A galeria vai passar a apresentar 12 fotografias 

O formulario de contacto deve ser traduzido para PT em todos os placeholders

No rodape o design by coloca o teu nome.

Nas redes sociais de cabeçalho e rodape remove twitter e skype

Devolver na tarefa o ficheiro index.html com o teu nome